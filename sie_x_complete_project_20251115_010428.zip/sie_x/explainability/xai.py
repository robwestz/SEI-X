# Explainable AI features for understanding extraction decisions
# [Full XAI content]
