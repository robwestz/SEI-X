# API middleware for auth, rate limiting, and request tracking
# [Full middleware.py content]
