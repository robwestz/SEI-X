# Core engine implementation (original from conversation)
# [Full content from our original implementation]
