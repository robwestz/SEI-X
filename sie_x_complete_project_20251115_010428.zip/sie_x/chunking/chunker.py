# Advanced document chunking with semantic boundaries
# [Full chunker content]
