# Production observability with structured logging and metrics
# [Full observability.py content]
